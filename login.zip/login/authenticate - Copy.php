<?php
// Database connection parameters
$host = "db4free.net";
$dbUsername = "deepashetty";
$dbPassword = "deepashetty";
$dbName = "loginpage18";

// Establish database connection
$connection = mysqli_connect($host, $dbUsername, $dbPassword, $dbName);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user input
$username = $_POST['username'];
$password = $_POST['password'];

// Query to fetch user credentials
$query = "SELECT id, username, password FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) === 1) {
    // Successful login
    $user = mysqli_fetch_assoc($result);
    echo "Welcome, " . $user['username'] . "!";

} else {
    // Invalid login
    echo "Invalid login credentials.";
}

mysqli_close($connection);
?>
