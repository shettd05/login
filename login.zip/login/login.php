<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login Panel</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  
  <div class="container">
    <div class="myform">
      <!-- <form>
        <h2>ADMIN LOGIN</h2>
        <input type="text" placeholder="Admin Name">
        <input type="password" placeholder="Password">
        <button type="submit">LOGIN</button>
      </form> -->
      <form action="authenticate.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br><br>
        
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br><br>
        
        <!-- <input type="submit" value="Login"> -->
        <button type="submit">LOGIN</button>
    </form>
    </div>
    <div class="image">
      <img src="image.jpg">
    </div>
  </div>

</body>
</html>